export default function AccountInfoPage() {
  return <div>this is account info page</div>;
}
