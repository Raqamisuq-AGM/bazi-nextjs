"use client";

export default function Table() {
  return <div>Table</div>;
}
