"use client";

export default function Footer() {
  return (
    <div className="text-center text-white p-5 font-xl footer">
      <h3>© Baji365 Live Agent List</h3>
    </div>
  );
}
