"use client"


import React from 'react'

export default function Complain() {
  return (
    <div className='complain-area'>
        <div className='p-5  text-center rounded-3'>
           <h2>QUICK MASTER AGENT NUMBER</h2>
        </div>

          <div className='content-body'>
            <div className='complain-content'>
                <ul>
                    <li><h5>Master</h5></li>
                    <li>David vai</li>
                    <li>66</li>
                    <li>*****</li>
                    <li><span>whatsapp</span> <span>Messanger</span></li>
                    <li>+84372881361</li>
                    <li><button >Complain</button></li>
                </ul>
            </div>
        </div>
          
    </div>
  )
}
