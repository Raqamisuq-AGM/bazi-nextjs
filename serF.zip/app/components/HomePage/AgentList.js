import React from 'react'

export default function AgentList() {
  return (
   <div className='content-area'>
      <div className='content-body'>
          <h2>BAJI365 AGENT LIST</h2>
        <h3>This is the Baji365 Live Online Official Agentlist Website.</h3><br/>
        <h4>You can see here Master Agent List, Super Agent List and also Baji365 Admin.</h4>

        <p>Baji365 is No.1 Betting Website in Bangladesh. From the beginning of this Website, It got much more popularity than other Betting sites in Bangladesh. Earlier its URL was (Baji365.Live) but now its URL is ( Baaji365.Live). The Admin of this website has changed its Link because of Spamming. Baaji365 is the best Betting website in Bangladesh.</p>
      </div>
    </div>
  )
}
