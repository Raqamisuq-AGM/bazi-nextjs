import React from 'react'

export default function SearchInput() {
  return (
   <input type="text" name="" placeholder='Search by Agent id no' />
  )
}
