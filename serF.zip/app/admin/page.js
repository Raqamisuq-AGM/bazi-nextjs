import Button from "../components/Common/Button";
import SearchInput from "../components/Common/SearchInput";

export const metadata = {
  title: "Admin Title",
  description: "Admin Description",
};

export default function AdminPage() {
  return(
    <div className="admin-page">
        
    </div>
  );
}
