export const metadata = {
  title: "Static Title",
  description: "Static Description",
};

export default function BlogPage() {
  return <div>this is blog page</div>;
}
